export default function DashboardPage() {
  return (
    <div className="text-gray-500 text-center text-lg">
      {/* Conteúdo da dashboard será adicionado futuramente */}
      <p>Bem-vindo ao Dashboard</p>
    </div>
  );
}
